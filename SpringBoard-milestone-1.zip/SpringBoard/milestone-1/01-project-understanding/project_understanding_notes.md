# Task 1 – Project Understanding Notes

## 1. Objective of the project
SpringBoard is an AI-powered tool that **validates startup ideas before money and time are spent building them**. A founder submits an idea; a team of specialised AI agents researches the web and returns a validation report covering market demand, competitors, SWOT/risks, and a recommended MVP.

## 2. Why startup ideas need validation
- Most startups fail because **nobody needs the product enough to pay for it**, not because of bad engineering.
- Building first and validating later is expensive; validating first is cheap (research, interviews, landing pages).
- Validation reduces risk by answering: *Is there a real problem? Who has it? Who already solves it? Can we make money?*
- Founders are biased toward their own idea; a structured, evidence-based report gives an outside view.

## 3. Core validation concepts

### 3.1 Market demand
- **Problem–solution fit:** is the problem frequent and painful enough that people actively look for solutions?
- **Market size:** TAM (total addressable market), SAM (serviceable available market), SOM (serviceable obtainable market).
- **Demand signals:** search trends, forum/Reddit/Quora complaints, existing spend in the category, growth reports, waitlist sign-ups.

### 3.2 Target customers
- Define a specific **customer segment** (who, where, age/role, income, behaviour) instead of "everyone".
- Identify **jobs-to-be-done**, current alternatives, and willingness to pay.
- Build 1–3 simple **personas** and validate through surveys or interviews.

### 3.3 Competitor analysis
- **Direct competitors:** same solution, same customer.
- **Indirect competitors:** different solution, same problem (including "do nothing" / manual methods).
- Compare on: features, pricing, target segment, reviews, funding, strengths, weaknesses.
- Find the **gap or differentiation** the startup can own.

### 3.4 Business feasibility
- **Technical:** can it be built with available skills, tools, and time?
- **Financial:** revenue model, unit economics, costs, break-even.
- **Operational:** supply chain, regulation/licences, team, logistics.
- **Legal/regulatory:** data privacy, food/health/finance rules, etc.

## 4. Typical validation workflow
1. Define the problem and customer hypothesis.
2. Desk research (market reports, trends, news).
3. Competitor scan.
4. Talk to potential customers (surveys, interviews).
5. Test demand (landing page, pre-orders, waitlist).
6. Build the smallest MVP that tests the riskiest assumption.
7. Measure, learn, iterate or pivot.

SpringBoard automates steps 1–3 and 6 (research + recommendation) and prepares the ground for steps 4–5.

## 5. Sample startup idea and how to validate it

### Idea: **CampusBite – hostel meal subscription for college students**
A subscription service delivering affordable, home-style, hygienic meals to students living in hostels and PGs around engineering college campuses.

| Field | Detail |
|-------|--------|
| Problem | Hostel/mess food is repetitive and often poor quality; outside food is costly and inconsistent; students have little time to cook |
| Target customers | Hostel and PG students aged 18–24 near college clusters; secondary: working bachelors in PGs |
| Industry | Food-tech / subscription delivery |
| Revenue model | Weekly/monthly meal plans; optional add-ons |
| Key hypothesis | Students will pay a premium over mess fees for reliable, home-style meals with flexible skip/pause |

### Validation plan
| Step | Method | Success signal |
|------|--------|----------------|
| 1. Demand | Survey ~100 hostel students; check search trends for "tiffin service near [college]"; scan forums for mess-food complaints | A large share report dissatisfaction and would try a paid alternative |
| 2. Customer | 10–15 interviews on current food spend, frequency, pain points | Clear, repeatable pain and measurable monthly food spend |
| 3. Competition | Map tiffin services, food-delivery subscriptions, mess contractors, cloud kitchens near campuses | Identifiable gap (price, flexibility, quality, hygiene) |
| 4. Feasibility | Estimate cost per meal, delivery cost, kitchen setup, licences (FSSAI) | Positive contribution margin at target price |
| 5. Smoke test | WhatsApp group or landing page with plan sign-up; 1-week pilot with ~20 students | Paid pilot customers and good week-2 retention |
| 6. MVP | Single kitchen, one campus, WhatsApp ordering, fixed menu | Sustained repeat orders |

**Riskiest assumption:** students will keep paying a premium over mess fees. The pilot tests this first.

*(Thresholds above are team-chosen targets, to be set before running the tests, not market facts.)*

## 6. How this feeds the project
This sample idea is the **running example** across the milestone: wireframe inputs and structured output (Task 4) and web search test queries (Task 5).
