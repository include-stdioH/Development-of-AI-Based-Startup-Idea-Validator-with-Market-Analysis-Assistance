# Task 3 – System Architecture

## 1. Architecture diagram
![Architecture](architecture.svg)

Mermaid version (renders directly on GitHub):

```mermaid
flowchart TD
    U[User / Founder] -->|submits idea| UI[Frontend UI<br/>Idea Submission Form]
    UI -->|POST /ideas| API[Backend API<br/>FastAPI / Orchestrator]
    API -->|raw text| LLM0[LLM: Idea Structuring]
    LLM0 -->|structured JSON| API
    API --> WS[Web Search Agent]
    WS <-->|queries / results| TAV[(Tavily Web Search API)]
    WS --> MA[Market Analysis Agent]
    WS --> CA[Competitor Analysis Agent]
    MA --> SW[SWOT & Risk Agent]
    CA --> SW
    SW --> MVP[MVP Recommendation Agent]
    MA --> MVP
    CA --> MVP
    MVP --> RG[Report Generation Agent]
    SW --> RG
    MA --> RG
    CA --> RG
    RG -->|final report| API
    API -->|report JSON / Markdown| UI
    UI --> U
    MA -.uses.-> LLM[(LLM)]
    CA -.uses.-> LLM
    SW -.uses.-> LLM
    MVP -.uses.-> LLM
    RG -.uses.-> LLM
```

## 2. Component roles

| Component | Role |
|-----------|------|
| **User interface** | Collects the startup idea (description, target customers, industry, extras), shows progress, and displays the final report |
| **Backend / orchestrator** | Validates input, calls the LLM to structure the idea, runs agents in order (parallel where possible), stores intermediate results, returns the report |
| **LLM** | Reasoning and language engine behind the structuring step and every analysis agent; receives role prompt + context, returns JSON/text |
| **Web search API (Tavily)** | Gives agents live market and competitor information with URLs, so reports rely on current evidence, not just model memory |
| **Agents** | Specialised LLM-driven workers (see Task 2) with defined inputs and outputs |
| **Storage (later milestone)** | Persist ideas, agent outputs, and reports (SQLite/PostgreSQL) |

## 3. Information flow: idea → report
1. **Submit:** user fills the form; the UI sends the raw fields to the backend.
2. **Structure:** the backend asks the LLM to convert the input into a validated JSON schema (Task 4).
3. **Search:** the Web Search Agent generates queries and calls Tavily; results are categorised (market / competitor / customer / regulation).
4. **Analyse (parallel):** Market Analysis and Competitor Analysis agents read the relevant results and produce their JSON outputs.
5. **Assess:** SWOT & Risk Agent combines the two analyses.
6. **Recommend:** MVP Agent uses all prior outputs to propose the MVP and experiments.
7. **Report:** Report Generation Agent assembles the final document.
8. **Deliver:** backend returns the report; the UI displays it (and later offers download).

## 4. Design decisions
- **Orchestrator pattern:** the backend controls order and retries; agents do not call each other directly.
- **JSON contracts** between agents keep the pipeline testable.
- **Parallel step** (3.4): market and competitor analysis are independent.
- **Failure handling:** if search returns little, agents lower confidence and say so; a failed agent can be retried without rerunning everything.
- **Suggested stack (proposal):** React or plain HTML frontend, Python FastAPI backend, Tavily search, an LLM API of the team's choice.
