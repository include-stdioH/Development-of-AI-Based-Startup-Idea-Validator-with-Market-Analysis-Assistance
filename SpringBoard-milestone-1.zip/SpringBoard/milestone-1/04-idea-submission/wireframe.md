# Task 4 – Startup Idea Submission Module

## 1. UI wireframe
Interactive version: open [`wireframe.html`](wireframe.html) in a browser.

```
+----------------------------------------------------------------+
|  SpringBoard                         Validate your startup idea |
+----------------------------------------------------------------+
|                                                                |
|  Startup name (optional)                                       |
|  [______________________________________________]             |
|                                                                |
|  Describe your startup idea *                                  |
|  +----------------------------------------------------------+  |
|  |                                                          |  |
|  |                                                          |  |
|  +----------------------------------------------------------+  |
|  What problem does it solve and how?          (0 / 1000)      |
|                                                                |
|  Target customers *                                            |
|  [______________________________________________]             |
|                                                                |
|  Industry *                       Business model (optional)   |
|  [ Select industry          v ]    [ Select model        v ]  |
|                                                                |
|  Target location / market (optional)                           |
|  [______________________________________________]             |
|                                                                |
|  Additional information (optional)                             |
|  +----------------------------------------------------------+  |
|  |  Budget, team, known competitors, unique advantage...    |  |
|  +----------------------------------------------------------+  |
|                                                                |
|                           [ Clear ]   [ Validate my idea  > ]  |
+----------------------------------------------------------------+
```

## 2. Fields
| Field | Required | Type | Notes |
|-------|:---:|------|-------|
| Startup name | No | text | |
| Idea description | Yes | textarea (20–1000 chars) | problem + solution |
| Target customers | Yes | text | who, where |
| Industry | Yes | dropdown | FoodTech, EdTech, HealthTech, FinTech, E-commerce, SaaS, AgriTech, Other |
| Business model | No | dropdown | Subscription, Marketplace, Freemium, One-time sale, Ads, Other |
| Target location | No | text | city / country |
| Additional info | No | textarea | budget, team, competitors, advantage |

## 3. Converting the submission to a structured format with an LLM
1. The UI sends the raw form fields to `POST /ideas`.
2. The backend validates required fields, then calls the LLM with the prompt in [`structuring_prompt.md`](structuring_prompt.md).
3. The LLM must return **only JSON** matching [`idea_schema.json`](idea_schema.json): it normalises wording, splits problem from solution, lists customer segments, and fills gaps as `null` rather than guessing.
4. The backend parses and validates the JSON against the schema (retry once on failure).
5. The structured idea is stored and passed to the agent pipeline.

Reference script: [`structure_idea.py`](structure_idea.py).

## 4. Sample structured output
See [`sample_structured_output.json`](sample_structured_output.json) (generated from the CampusBite example in Task 1).
