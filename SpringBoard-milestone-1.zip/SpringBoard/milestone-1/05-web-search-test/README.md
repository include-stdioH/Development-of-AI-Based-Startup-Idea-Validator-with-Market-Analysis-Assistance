# Task 5 – Web Search API Integration (Tavily)

## Why a web search API?
LLMs have a training cutoff and cannot browse on their own. A search API gives agents **live** information (market reports, competitor sites, pricing, news, regulations) with source URLs, so validation reports are grounded in current evidence and can be cited.

## Why Tavily?
Built for LLM/agent use: returns clean snippets, relevance scores, optional short answers, and has a free tier suitable for a student project. Alternatives: SerpAPI, Brave Search API, Serper, Bing/Google programmable search.

## Getting an API key
1. Sign up at https://app.tavily.com
2. Copy the API key from the dashboard (format `tvly-...`)
3. Put it in `.env` as `TAVILY_API_KEY=...` (never commit `.env`)

Check Tavily's site for the current free-tier credit limits.

## Run the test
```bash
pip install -r requirements.txt
cp .env.example .env     # add your key
python tavily_test.py
```
The script runs four searches (market, competitors, customer pain points, regulation) for the CampusBite sample idea and prints readable results. It also writes:
- `sample_results.json` – raw API responses
- `sample_results.md` – readable output (**commit this after running as your deliverable evidence**)

## Minimal request
```python
from tavily import TavilyClient
client = TavilyClient(api_key="tvly-...")
resp = client.search("hostel meal subscription India", max_results=5)
for r in resp["results"]:
    print(r["title"], r["url"], r["score"])
```

## Response fields used
| Field | Meaning |
|-------|---------|
| `results[].title` / `url` | Source page |
| `results[].content` | Relevant extracted snippet |
| `results[].score` | Relevance score |
| `answer` | Optional short summary (`include_answer=True`) |

## How the Web Search Agent will use this
Generate queries from `search_keywords` in the structured idea → call Tavily per category → filter by score → pass snippets and URLs to the Market and Competitor agents.
