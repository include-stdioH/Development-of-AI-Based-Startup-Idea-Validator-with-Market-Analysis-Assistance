"""Task 5 – Web search API test using Tavily.

Run:
    pip install -r requirements.txt
    cp .env.example .env   # add TAVILY_API_KEY
    python tavily_test.py

Outputs:
    - readable results printed to the terminal
    - sample_results.json  (raw results)
    - sample_results.md    (readable report, commit this as your sample output)
"""
import json
import os
import sys
from datetime import date
from pathlib import Path

from dotenv import load_dotenv
from tavily import TavilyClient

load_dotenv()
API_KEY = os.getenv("TAVILY_API_KEY")
if not API_KEY:
    sys.exit("TAVILY_API_KEY not found. Copy .env.example to .env and add your key "
             "(get one free at https://app.tavily.com).")

# Sample idea: CampusBite (see Task 1 / Task 4)
IDEA = "CampusBite – hostel meal subscription for college students in Chennai"
QUERIES = {
    "Market": "college student meal subscription tiffin service market India",
    "Competitors": "tiffin service meal subscription for hostel students Chennai",
    "Customer pain points": "hostel mess food quality complaints students India",
    "Regulation": "FSSAI licence requirements for home kitchen food business",
}
MAX_RESULTS = 5

client = TavilyClient(api_key=API_KEY)


def run_search(query: str) -> dict:
    return client.search(
        query=query,
        search_depth="basic",     # "advanced" gives deeper results (uses more credits)
        max_results=MAX_RESULTS,
        include_answer=True,      # short AI-generated summary of the results
    )


def main() -> None:
    all_results, lines = {}, [f"# Web Search Test – Sample Results\n",
                              f"**Idea:** {IDEA}  \n**Date run:** {date.today()}  \n**API:** Tavily\n"]
    for category, query in QUERIES.items():
        print(f"\n=== {category} ===\nQuery: {query}")
        try:
            resp = run_search(query)
        except Exception as e:  # noqa: BLE001
            print(f"  Search failed: {e}")
            lines.append(f"## {category}\n_Search failed: {e}_\n")
            continue
        all_results[category] = resp
        lines += [f"## {category}", f"**Query:** `{query}`\n"]
        if resp.get("answer"):
            print(f"Summary: {resp['answer']}")
            lines.append(f"**Summary:** {resp['answer']}\n")
        for i, r in enumerate(resp.get("results", []), 1):
            snippet = " ".join(r.get("content", "").split())[:300]
            print(f"  {i}. {r['title']}\n     {r['url']}\n     (score {r.get('score', 0):.2f}) {snippet}...")
            lines.append(f"{i}. [{r['title']}]({r['url']}) – relevance {r.get('score', 0):.2f}  \n   {snippet}...")
        lines.append("")

    Path("sample_results.json").write_text(json.dumps(all_results, indent=2))
    Path("sample_results.md").write_text("\n".join(lines))
    print("\nSaved sample_results.json and sample_results.md")


if __name__ == "__main__":
    main()
