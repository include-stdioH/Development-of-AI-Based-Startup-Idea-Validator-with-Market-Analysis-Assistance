# Milestone 1 – Foundations & Design

**Due:** 12 October 2026

| # | Task | Deliverable | Location |
|---|------|-------------|----------|
| 1 | Project understanding & startup validation | Notes + sample startup idea | [`01-project-understanding/`](01-project-understanding/project_understanding_notes.md) |
| 2 | Multi-agent AI systems | Agent roles & responsibilities | [`02-agent-roles/`](02-agent-roles/agent_roles_and_responsibilities.md) |
| 3 | System architecture | Architecture diagram + data flow | [`03-architecture/`](03-architecture/architecture.md) |
| 4 | Idea submission module | UI wireframe + sample structured output | [`04-idea-submission/`](04-idea-submission/) |
| 5 | Web search API | Working Tavily test + sample results | [`05-web-search-test/`](05-web-search-test/) |

## Quick start (Task 5 test)
```bash
cd milestone-1/05-web-search-test
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then paste your Tavily API key into .env
python tavily_test.py
```
